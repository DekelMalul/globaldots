def up_str(str):
    return str.upper()
def low_str(str):
    return str.lower()
