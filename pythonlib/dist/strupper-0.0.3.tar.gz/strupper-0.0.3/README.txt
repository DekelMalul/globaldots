simple upper string lib
