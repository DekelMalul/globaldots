def up_str(str):
    return str.upper()

